export enum PushNotificationResponseEnum {
  SUCCEEDED = "succeeded",
  FAILED = "failed",
}
