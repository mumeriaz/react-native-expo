export type AppVersion = {
  platform: string;
  version: string;
};
