export const KEYS = {
  AUTH: {
    TOKEN: "access_token",
    USER: "user",
  },
};
