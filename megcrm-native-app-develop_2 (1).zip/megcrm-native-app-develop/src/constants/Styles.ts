export const STYLES = {
  FONTS: {
    REGULAR: "Poppins_400Regular",
    REGULAR_ITALIC: "Poppins_400Regular_Italic",
    MEDIUM: "Poppins_500Medium",
    MEDIUM_ITALIC: "Poppins_500Medium_Italic",
    SEMIBOLD: "Poppins_600SemiBold",
    SEMIBOLD_ITALIC: "Poppins_600SemiBold_Italic",
    BOLD: "Poppins_700Bold",
    BOLD_ITALIC: "Poppins_700Bold_Italic",
  },
};
