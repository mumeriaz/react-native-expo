export const BASE_URL = "http://192.168.1.210:8000/api";
export const API_VERSION = "/V1";
export const EXPONENT_STORE = "/exponent/devices/subscribe";
